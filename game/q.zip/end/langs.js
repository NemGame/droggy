const langs = {
    "hu": {
        "cim": "Nevek és feladatok:",
        "akos": "Játék megírása és ahhoz a dokumentáció, ötletelés, navigációs sáv és nyelvváltás megírása",
        "zsombor": "Játék rajzok készítése, ötletelés, a fő, az rólunk és az AAAA oldalak megírása",
        "benedek": "Professzionális információk gyűjtése életszerűbb játékélményért"
    },
    "en": {
        "cim": "Names and tasks:",
        "akos": "Game development, ideas, navigation bar and language switching",
        "zsombor": "Game art, ideas, main, about us and AAAA pages",
        "benedek": "Professional information gathering for a more realistic game experience"
    }
}