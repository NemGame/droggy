const langs = {
    "hu": {
        "title": "valami",
        "q": "Melyik nem egészséges?",
        "broccoli": "Brokkoli",
        "alma": "Alma",
        "birs": "Birs",
        "fries": "Hasáb krumpli"
    },
    "en": {
        "title": "something",
        "q": "Which one is not healthy?",
        "broccoli": "Broccoli",
        "alma": "Apple",
        "birs": "Birs",
        "fries": "French fries"
    }
}