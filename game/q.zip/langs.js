const langs = {
    "hu": {
        "cim": "Étkezz egészségesen",
        "stuff": "Megtanít az egészséges étkezésre"
    },
    "en": {
        "cim": "Eat healthy",
        "stuff": "Learn how to eat healthy"
    }
}