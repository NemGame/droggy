const langs = {
    "hu": {

    },
    "en": {
        
    }
}