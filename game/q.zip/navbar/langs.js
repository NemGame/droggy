const langs = {
    "hu": {
        "play": "Játék",
        "aaaa": "AAAA",
        "docs": "Dokumentáció",
        "aboutus": "Rólunk",
        "main": "Főoldal"
    },
    "en": {
        "play": "Play",
        "aaaa": "AAAA",
        "docs": "Documentation",
        "aboutus": "About us",
        "main": "Main"
    }
}